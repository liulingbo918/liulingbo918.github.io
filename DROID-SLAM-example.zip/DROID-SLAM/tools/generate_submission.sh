#!/bin/bash
#choose which gpu you want to use
export CUDA_VISIBLE_DEVICES=1

##################### testing on vlc data #########################
# assign the input photos
VLC_DATA_PATH='Path/to/your/test/images' # where you save the 'test_images.zip' file (the test images)
VLC_SUBFORMAT='data/submission_format.csv' # where you save the 'submission_format.csv' file
VLC_CALIBPATH='calib/intrinsic_parameters.json' # where you save the 'intrinsic_parameters.json'
VLC_MODELPATH='droid.pth' # where you save the 'intrinsic_parameters.json'
# python code for inference
python evaluation_scripts/infer_vlc.py --datapath=$VLC_DATA_PATH --gt=$VLC_SUBFORMAT --weights=$VLC_MODELPATH --calib=$VLC_CALIBPATH
