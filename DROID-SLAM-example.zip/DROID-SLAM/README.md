# DROID-SLAM


<center><img src="misc/DROID.png" width="640" style="center"></center>


[![IMAGE ALT TEXT HERE](misc/screenshot.png)](https://www.youtube.com/watch?v=GG78CSlSHSA)



[DROID-SLAM: Deep Visual SLAM for Monocular, Stereo, and RGB-D Cameras](https://arxiv.org/abs/2108.10869)  
Zachary Teed and Jia Deng

```
@article{teed2021droid,
  title={{DROID-SLAM: Deep Visual SLAM for Monocular, Stereo, and RGB-D Cameras}},
  author={Teed, Zachary and Deng, Jia},
  journal={Advances in neural information processing systems},
  year={2021}
}
```

**Notification:** This repo is based on the official repo of [DROID-SLAM](https://github.com/princeton-vl/DROID-SLAM). We provide a demo scheme that how to generate a submission to [AISG-VLC Visual Localization Challenge](https://prizechallenge.aisingapore.org/competitions/1/visual-localisation/). To run the demo you will need a GPU with at least 11G of memory.

## Getting Started
1. For the basic knowledge of camera pose estimation, you are encouraged to refer to this [slides from CMU](https://www.cs.cmu.edu/~16385/s17/Slides/11.3_Pose_Estimation.pdf). For designing your own solution to this problem, the following lists of papers and code could help you.

* **Deep visual odometry:** https://github.com/hassaanhashmi/awesome-deep-visual-odometry
* **Deep SLAM:** https://github.com/cuge1995/Deep-SLAM

You can also refer to the recent academic work [DiffPoseNet](https://prg.cs.umd.edu/DiffPoseNet)

2. Creating a new anaconda environment using the provided .yaml file. Use `environment_novis.yaml` to if you do not want to use the visualization
```Bash
conda env create -f environment.yaml
pip install evo --upgrade --no-binary evo
pip install gdown
```

3. Compile the extensions (takes about 10 minutes)
```Bash
python setup.py install
```


## Demos

1. Download the model from google drive: [droid.pth](https://drive.google.com/file/d/1PpqVt1H4maBa_GbPJp4NwxRsd9jk-elh/view?usp=sharing)

2. Download the test image data from [challenge website](https://prizechallenge.aisingapore.org/competitions/1/visual-localisation/data/).
```Bash
./tools/generate_submission.sh
```
