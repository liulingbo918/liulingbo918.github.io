from operator import gt
import sys
from tkinter import UNITS
sys.path.append('droid_slam')

from tqdm import tqdm
import numpy as np
import torch
import lietorch
import cv2
import os
import glob 
import time
import argparse
import pdb
import pandas as pd
import math
import csv
from matplotlib import pyplot as plt
import pdb
import json

from torch.multiprocessing import Process
from droid import Droid

import torch.nn.functional as F

def show_image(image):
    # pdb.set_trace()
    image = image.squeeze(0).permute(1, 2, 0).cpu().numpy()
    cv2.imshow('image', image / 255.0)
    cv2.waitKey(1)

def image_stream(datapath, test_format, calibfile):
    """ image generator """

    # fx, fy, cx, cy = np.loadtxt('calib/aisg_sla.txt').tolist()
    with open(calibfile, 'r') as f:
        calib = json.load(f)
    fx, fy, cx, cy = calib['fx'], calib['fy'], calib['Cx'], calib['Cy']
    test_format = pd.read_csv(test_format)
    img_list = test_format['Filename'].values.tolist()  
    img_list = [datapath+x for x in img_list]
    # pdb.set_trace()

    for t, img_name in enumerate(img_list):
        image = cv2.imread(img_name)
        h0, w0, _ = image.shape
        # pdb.set_trace()
        h1, w1 = 184, 256 # resize the input image due to limited GPU memory
        # pdb.set_trace()
        image = cv2.resize(image, (w1, h1))
        image = torch.as_tensor(image).permute(2, 0, 1)

        intrinsics = torch.as_tensor([fx, fy, cx, cy])
        intrinsics[0::2] *= (w1 / w0)
        intrinsics[1::2] *= (h1 / h0)
        # print("intrinsic matrix: {}".format(intrinsics[2:]))

        yield t, image[None], intrinsics

def euler_to_quaternion(roll, pitch, yaw):

    roll = math.radians(roll)
    pitch = math.radians(pitch)
    yaw = math.radians(yaw)
    cy = np.cos(yaw * 0.5)
    sy = np.sin(yaw * 0.5)
    cp = np.cos(pitch * 0.5)
    sp = np.sin(pitch * 0.5)
    cr = np.cos(roll * 0.5)
    sr = np.sin(roll * 0.5)

    w = cy * cp * cr + sy * sp * sr
    x = cy * cp * sr - sy * sp * cr
    y = sy * cp * sr + cy * sp * cr
    z = sy * cp * cr - cy * sp * sr

    return np.array([w, x, y, z])

def quaternion_to_euler(w, x, y, z):
    ysqr = y * y

    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + ysqr)
    X = np.degrees(np.arctan2(t0, t1))

    t2 = +2.0 * (w * y - z * x)
    t2 = np.where(t2>+1.0,+1.0,t2)
    #t2 = +1.0 if t2 > +1.0 else t2

    t2 = np.where(t2<-1.0, -1.0, t2)
    #t2 = -1.0 if t2 < -1.0 else t2
    Y = np.degrees(np.arcsin(t2))

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (ysqr + z * z)
    Z = np.degrees(np.arctan2(t3, t4))

    return X, Y, Z 


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--datapath", help="path to euroc sequence")
    parser.add_argument("--gt", help="path to gt file")
    parser.add_argument("--calib", type=str, help="path to json calib file")
    parser.add_argument("--weights", default="droid.pth")
    parser.add_argument("--buffer", type=int, default=1024)
    parser.add_argument("--image_size", default=[184, 256])
    parser.add_argument("--disable_vis", action="store_true")
    parser.add_argument("--stereo", action="store_true")
    parser.add_argument("--upsample", type=bool, default=False)

    parser.add_argument("--beta", type=float, default=0.3)
    parser.add_argument("--filter_thresh", type=float, default=2.4)
    parser.add_argument("--warmup", type=int, default=15)
    parser.add_argument("--keyframe_thresh", type=float, default=3.5)
    parser.add_argument("--frontend_thresh", type=float, default=17.5)
    parser.add_argument("--frontend_window", type=int, default=20)
    parser.add_argument("--frontend_radius", type=int, default=2)
    parser.add_argument("--frontend_nms", type=int, default=1)

    parser.add_argument("--backend_thresh", type=float, default=24.0)
    parser.add_argument("--backend_radius", type=int, default=2)
    parser.add_argument("--backend_nms", type=int, default=2)
    parser.add_argument("--reconstruction_path", help="path to saved reconstruction")
    args = parser.parse_args()

    torch.multiprocessing.set_start_method('spawn')

    print("Running inference on {}".format(args.datapath))
    print(args)

    droid = Droid(args)
    time.sleep(5)

    for (t, image, intrinsics) in tqdm(image_stream(args.datapath, args.gt, args.calib)):
        droid.track(t, image, intrinsics=intrinsics)

    traj_est = droid.terminate(image_stream(args.datapath, args.gt, args.calib))

    df = pd.read_csv(args.gt)
    x, y, z = quaternion_to_euler(traj_est[:,3], traj_est[:,4], traj_est[:,5], traj_est[:,6])
    data = np.hstack((traj_est[:,:3], x[:,None], y[:,None], z[:,None]))
    df.iloc[:,-6:]=data
    df.to_csv('submissions_demo_model.csv', index=False)


